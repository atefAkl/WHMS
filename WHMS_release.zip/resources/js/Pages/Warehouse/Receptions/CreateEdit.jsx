import React, { useState, useEffect, useRef, useMemo } from "react";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { Head, useForm, Link, router, usePage } from "@inertiajs/react";
import { useLang } from "@/Contexts/LanguageContext";
import {  AlertCircle, ArrowRight, Box, Calculator, CheckCircle2, ChevronDown, ChevronRight, ChevronUp, Edit, FolderSync, Home, Layers, Plus, Printer, RefreshCw, Save, Search, Trash2, Unlock, UserPlus, X } from "lucide-react";
import Modal from "@/Components/Modal";
import ConfirmationModal from "@/Components/ConfirmationModal";
import { useSecureDelete } from "@/Hooks/useSecureDelete";
import TextInput from "@/Components/TextInput";
import InputLabel from "@/Components/InputLabel";
import InputError from "@/Components/InputError";
import PrimaryButton from "@/Components/PrimaryButton";
import SecondaryButton from "@/Components/SecondaryButton";
import DangerButton from "@/Components/DangerButton";
import PageHeader from "@/Components/PageHeader";
import Tooltip from "@/Components/Tooltip";
import SearchableSelect from "@/Components/SearchableSelect";
import axios from "axios";

export default function CreateEdit({
    customers = [],
    drivers = [],
    inventoryItems = [],
    isEdit = false,
    reception = null,
    draftReceptions = [],
}) {
    const { lang, __ } = useLang();

    // Translation Helper
    const t = (key, fallbackAr = "", fallbackEn = "") => {
        if (key && __) {
            const translated = __(key);
            if (translated && translated !== key) {
                return translated;
            }
        }
        return lang === "en" ? (fallbackEn || fallbackAr || key) : (fallbackAr || fallbackEn || key);
    };

    const { auth } = usePage().props;
    const user = auth.user;
    const showButtonText = user?.preferences?.show_button_text ?? false;

    // Driver quick creation modal
    const [isDriverModalOpen, setDriverModalOpen] = useState(false);
    const [driverList, setDriverList] = useState(drivers);
    const [newDriverData, setNewDriverData] = useState({
        name: "",
        phone_number: "",
        id_number: "",
        vehicle_plate: "",
        vehicle_type: "",
        license_number: "",
    });
    const [driverError, setDriverError] = useState("");
    const [addingDriver, setAddingDriver] = useState(false);

    // Dynamic Lists based on selection
    const [availableContracts, setAvailableContracts] = useState([]);
    const [availablePeriods, setAvailablePeriods] = useState([]);
    const [availableRepresentatives, setAvailableRepresentatives] = useState(
        [],
    );

    // Live occupancy stats for selected contract
    const [contractStats, setContractStats] = useState(null);
    const [loadingStats, setLoadingStats] = useState(false);

    // Customer Autocomplete state
    const [customerSearch, setCustomerSearch] = useState("");
    const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);

    // POS Row temporary inputs state
    const [posPalletNumber, setPosPalletNumber] = useState("");
    const [posPalletSize, setPosPalletSize] = useState("وسط");
    const [posItemSearch, setPosItemSearch] = useState("");
    const [showPosItemDropdown, setShowPosItemDropdown] = useState(false);
    const [posItemId, setPosItemId] = useState("");
    const [posVariantId, setPosVariantId] = useState("");
    const [posQuality, setPosQuality] = useState("");
    const [posQuantity, setPosQuantity] = useState("");
    const [posRowError, setPosRowError] = useState("");
    const [loadingPallet, setLoadingPallet] = useState(false);
    const [palletLookupData, setPalletLookupData] = useState(null);
    const [editingRowIndex, setEditingRowIndex] = useState(null);

    // Active autocomplete indexes for ArrowUp/ArrowDown selection
    const [customerActiveIndex, setCustomerActiveIndex] = useState(-1);
    const [posItemActiveIndex, setPosItemActiveIndex] = useState(-1);

    // Sidebar stats collapse state (toggled by user to save screen space)
    const [isStatsCollapsed, setIsStatsCollapsed] = useState(false);

    // General information panel collapse state (toggled by user to save screen space)
    const [isGeneralCollapsed, setIsGeneralCollapsed] = useState(false);

    // Deletion Modal state
    const {
        itemToDelete: deleteItem,
        deletePassword,
        setDeletePassword,
        deleteError,
        processing: processingDelete,
        requestDelete,
        confirmDelete,
        cancelDelete,
    } = useSecureDelete();

    // Reset active index when search text changes or dropdown toggles
    useEffect(() => {
        setCustomerActiveIndex(-1);
    }, [customerSearch, showCustomerDropdown]);

    useEffect(() => {
        setPosItemActiveIndex(-1);
    }, [posItemSearch, showPosItemDropdown]);

    // Refs for keyboard navigation
    const palletInputRef = useRef(null);
    const sizeSelectRef = useRef(null);
    const itemSearchRef = useRef(null);
    const variantSelectRef = useRef(null);
    const qualityInputRef = useRef(null);
    const qtyInputRef = useRef(null);
    const addButtonRef = useRef(null);

    // Form setup using Inertia useForm
    const { data, setData, post, put, processing, errors } = useForm({
        customer_id: reception?.customer_id || "",
        contract_id: reception?.contract_id || "",
        period_id: reception?.period_id || "",
        driver_id: reception?.driver_id || "",
        representative_id: reception?.representative_id || "",
        farm_source: reception?.farm_source || "",
        notes: reception?.notes || "",
        reception_date: reception?.reception_date
            ? new Date(reception.reception_date).toISOString().split("T")[0]
            : new Date().toISOString().split("T")[0],
        modification_reason: "",
        status: reception?.status || "draft",
        items: reception?.inventory_entries
            ? reception.inventory_entries.map((e) => ({
                id: e.id,
                inventory_item_id: e.inventory_item_id,
                inventory_item_variant_id: e.inventory_item_variant_id,
                pallet_number: e.pallet?.pallet_number || "",
                pallet_size: e.pallet?.size || "وسط",
                quantity_in: e.quantity_in,
            }))
            : [],
        redirect_to_draft_id: "",
    });

    const totalReception =
        data.items?.reduce(
            (sum, item) => sum + parseFloat(item.quantity_in || 0),
            0,
        ) || 0;

    // Bilingual display utility
    const displayBilingual = (rawText) => {
        if (!rawText) return "";
        const parts = rawText.split("|").map((s) => s.trim());
        if (parts.length > 1) {
            return lang === "ar" ? parts[0] : parts[1];
        }
        return rawText;
    };

    // Global keyboard shortcuts (Ctrl+S: stay in Edit, Ctrl+Shift+S: go to Index, Ctrl+E: go to Print, Ctrl+D: Delete)
    useEffect(() => {
        const handleGlobalShortcuts = (e) => {
            if (!e.ctrlKey) return;

            if (e.code === "KeyS") {
                e.preventDefault();
                if (e.shiftKey) {
                    // Ctrl + Shift + S: Save draft and go to Index
                    handleFormSubmitWithStatus("draft", "index");
                } else {
                    // Ctrl + S: Save draft and remain in Edit
                    handleFormSubmitWithStatus("draft", "edit");
                }
            } else if (e.code === "KeyE") {
                e.preventDefault();
                // Ctrl + E: Save approved and go to Print
                handleFormSubmitWithStatus("approved", "print");
            } else if (e.code === "KeyD") {
                e.preventDefault();
                // Ctrl + D: Open delete confirmation modal
                if (reception) {
                    requestDelete(
                        route("receptions.destroy", reception.id),
                        reception,
                    );
                }
            }
        };
        window.addEventListener("keydown", handleGlobalShortcuts);
        return () =>
            window.removeEventListener("keydown", handleGlobalShortcuts);
    }, [data, reception]);

    const allContracts = useMemo(() => {
        const list = [];
        customers.forEach((cust) => {
            (cust.contracts || []).forEach((cnt) => {
                list.push({
                    ...cnt,
                    customer: cust,
                    customer_name: cust.name,
                    customer_id: cust.id,
                });
            });
        });
        return list;
    }, [customers]);

    // Populate initial customer autocomplete search field if editing
    useEffect(() => {
        if (data.customer_id) {
            const customer = customers.find(
                (c) => c.id === parseInt(data.customer_id),
            );
            if (customer) {
                setCustomerSearch(customer.name);
                setAvailableContracts(customer.contracts || []);
            }
        }
    }, [data.customer_id, customers]);

    const handleContractSelect = (contractId) => {
        if (!contractId) {
            setData((d) => ({
                ...d,
                contract_id: "",
                period_id: "",
                representative_id: "",
            }));
            setAvailablePeriods([]);
            setAvailableRepresentatives([]);
            return;
        }

        const selectedContract = allContracts.find(
            (c) => c.id === parseInt(contractId)
        );

        if (selectedContract) {
            const cust = customers.find((c) => c.id === selectedContract.customer_id) || selectedContract.customer;
            const activePeriods = (selectedContract.periods || []).filter(
                (p) => p.status === "active"
            );
            const activePeriod = activePeriods[0] || (selectedContract.periods || [])[0];

            setCustomerSearch(cust?.name || "");
            setAvailableContracts(cust?.contracts || [selectedContract]);
            setAvailablePeriods(activePeriods.length > 0 ? activePeriods : (selectedContract.periods || []));
            setAvailableRepresentatives(selectedContract.contract_agents || []);

            setData((d) => ({
                ...d,
                customer_id: selectedContract.customer_id,
                contract_id: selectedContract.id,
                period_id: activePeriod?.id || "",
                representative_id: selectedContract.contract_agents?.[0]?.id || "",
            }));
        }
    };

    // Handle customer contracts change
    useEffect(() => {
        if (data.customer_id) {
            const customer = customers.find(
                (c) => c.id === parseInt(data.customer_id),
            );
            if (customer) {
                setAvailableContracts(customer.contracts || []);
                if (
                    !isEdit &&
                    !customer.contracts?.some(
                        (c) => c.id === parseInt(data.contract_id),
                    )
                ) {
                    const firstContract = customer.contracts?.[0];
                    if (firstContract) {
                        handleContractSelect(firstContract.id);
                    } else {
                        setData((d) => ({
                            ...d,
                            contract_id: "",
                            period_id: "",
                            representative_id: "",
                        }));
                    }
                }
            }
        } else {
            setAvailableContracts([]);
            setAvailablePeriods([]);
            setAvailableRepresentatives([]);
        }
    }, [data.customer_id]);

    // Fetch contract occupancy stats
    useEffect(() => {
        if (data.contract_id) {
            setLoadingStats(true);
            axios
                .get(route("api.contracts.occupancy-stats", data.contract_id))
                .then((res) => {
                    setContractStats(res.data);
                    setLoadingStats(false);
                })
                .catch((err) => {
                    console.error(err);
                    setContractStats(null);
                    setLoadingStats(false);
                });
        } else {
            setContractStats(null);
        }
    }, [data.contract_id]);

    // Autocomplete filter for customer
    const filteredCustomers = customers.filter((c) =>
        c.name.toLowerCase().includes(customerSearch.toLowerCase()),
    );

    // Autocomplete filter for inventory item in POS Row
    const filteredPOSItems = inventoryItems.filter(
        (item) =>
            item.name.toLowerCase().includes(posItemSearch.toLowerCase()) ||
            item.code.toLowerCase().includes(posItemSearch.toLowerCase()),
    );

    // Selected POS item variants
    const selectedPOSItem = inventoryItems.find(
        (i) => i.id === parseInt(posItemId),
    );
    const posVariants = selectedPOSItem?.variants || [];

    // Trigger auto-quality loading when variant changes
    useEffect(() => {
        if (posVariantId && posVariants.length > 0) {
            const variant = posVariants.find(
                (v) => v.id === parseInt(posVariantId),
            );
            if (variant) {
                setPosQuality(displayBilingual(variant.quality) || "");
            }
        } else {
            setPosQuality("");
        }
    }, [posVariantId, posVariants]);

    // Handle Pallet blur to lookup details
    const handlePalletBlur = () => {
        const number = posPalletNumber.trim();
        if (!number) {
            setPalletLookupData(null);
            return;
        }

        // Strict requirement: Must select contract first before looking up pallet details
        if (!data.contract_id) {
            setPalletLookupData(null);
            setPosRowError(
                __("receptions.create_edit.please_select_a_contract_first")
            );
            return;
        }

        setLoadingPallet(true);
        setPosRowError("");

        axios
            .get(route("api.pallets.lookup", { pallet_number: number, contract_id: data.contract_id }))
            .then((res) => {
                setLoadingPallet(false);
                if (res.data) {
                    setPosPalletSize(res.data.size);
                    setPalletLookupData(res.data);
                }
            })
            .catch((err) => {
                setLoadingPallet(false);
                setPalletLookupData(null);
                console.error(err);
                setPosRowError(
                    __("receptions.create_edit.error_checking_pallet_code"),
                );
            });
    };

    // Driver creation handler
    const handleCreateDriver = (e) => {
        e.preventDefault();
        setDriverError("");
        setAddingDriver(true);

        axios
            .post(route("api.drivers.store"), newDriverData)
            .then((res) => {
                setAddingDriver(false);
                if (res.data.success) {
                    setDriverList((prev) => [...prev, res.data.driver]);
                    setData("driver_id", res.data.driver.id);
                    setDriverModalOpen(false);
                    setNewDriverData({
                        name: "",
                        phone_number: "",
                        id_number: "",
                        vehicle_plate: "",
                        vehicle_type: "",
                        license_number: "",
                    });
                }
            })
            .catch((err) => {
                setAddingDriver(false);
                if (err.response?.data?.message) {
                    setDriverError(err.response.data.message);
                } else {
                    setDriverError(
                        __("receptions.create_edit.could_not_add_driver"),
                    );
                }
            });
    };

    // Switch draft and auto-save current as draft
    const handleSwitchDraft = (targetDraftId) => {
        const currentData = {
            ...data,
            status: "draft",
            redirect_to_draft_id: targetDraftId,
        };

        if (isEdit) {
            router.put(route("receptions.update", reception.id), currentData);
        } else {
            router.post(route("receptions.store"), currentData);
        }
    };

    // Save and submit form with specific status
    const handleFormSubmitWithStatus = (statusValue, redirectTo = "") => {
        const currentData = {
            ...data,
            status: statusValue,
            redirect_to: redirectTo,
        };

        if (isEdit) {
            router.put(route("receptions.update", reception.id), currentData);
        } else {
            router.post(route("receptions.store"), currentData);
        }
    };

    // Confirm Secure Delete handled by hook

    // Default form submit handler
    const handleSubmit = (e) => {
        e.preventDefault();
        handleFormSubmitWithStatus(data.status);
    };

    // Add or Update POS Row in reception items array
    const handleAddPOSRow = () => {
        setPosRowError("");
        if (!posPalletNumber.trim()) {
            setPosRowError(
                __("receptions.create_edit.pallet_number_is_required"),
            );
            palletInputRef.current?.focus();
            return;
        }
        if (!posItemId) {
            setPosRowError(
                __("receptions.create_edit.inventory_item_is_required"),
            );
            itemSearchRef.current?.focus();
            return;
        }
        if (!posVariantId) {
            setPosRowError(
                __("receptions.create_edit.variant_is_required"),
            );
            variantSelectRef.current?.focus();
            return;
        }
        if (!posQuantity || parseFloat(posQuantity) <= 0) {
            setPosRowError(
                __("receptions.create_edit.quantity_must_be_greater_than_"),
            );
            qtyInputRef.current?.focus();
            return;
        }

        const newItem = {
            id: editingRowIndex !== null ? data.items[editingRowIndex]?.id : undefined,
            inventory_item_id: parseInt(posItemId),
            inventory_item_variant_id: parseInt(posVariantId),
            pallet_number: posPalletNumber.trim(),
            pallet_size: posPalletSize,
            quantity_in: parseFloat(posQuantity),
        };

        if (editingRowIndex !== null) {
            const updated = [...data.items];
            updated[editingRowIndex] = newItem;
            setData("items", updated);
            setEditingRowIndex(null);
        } else {
            setData("items", [...data.items, newItem]);
        }

        palletInputRef.current?.focus();
        palletInputRef.current?.select();
    };

    const handleEditItemRow = (index) => {
        const itemToEdit = data.items[index];
        if (!itemToEdit) return;

        setEditingRowIndex(index);
        setPosPalletNumber(itemToEdit.pallet_number || "");
        setPosPalletSize(itemToEdit.pallet_size || "وسط");
        setPosItemId(itemToEdit.inventory_item_id ? String(itemToEdit.inventory_item_id) : "");
        setPosVariantId(itemToEdit.inventory_item_variant_id ? String(itemToEdit.inventory_item_variant_id) : "");
        setPosQuantity(itemToEdit.quantity_in ? String(itemToEdit.quantity_in) : "");

        const itemObj = inventoryItems.find((i) => i.id === itemToEdit.inventory_item_id);
        if (itemObj) {
            setPosItemSearch(itemObj.name);
        }

        setPosRowError("");
        palletInputRef.current?.focus();
        palletInputRef.current?.select();
    };

    const handleCancelEditRow = () => {
        setEditingRowIndex(null);
        setPosRowError("");
        setPosPalletNumber("");
        setPosItemSearch("");
        setPosItemId("");
        setPosVariantId("");
        setPosQuantity("");
    };

    const handleRemoveItemRow = (index) => {
        if (editingRowIndex === index) {
            handleCancelEditRow();
        }
        const updated = [...data.items];
        updated.splice(index, 1);
        setData("items", updated);
    };

    // Handle keydown navigation (Arrows navigation)
    const handleKeyNavigation = (e, nextRef, prevRef) => {
        if (e.key === "ArrowRight" && nextRef) {
            e.preventDefault();
            nextRef.current?.focus();
        } else if (e.key === "ArrowLeft" && prevRef) {
            e.preventDefault();
            prevRef.current?.focus();
        }
    };

    // Calculate live occupancy stats based on unsaved/modified items in the form
    const initialPalletsCount = reception?.inventory_entries?.length || 0;
    const netChange = data.items.length - initialPalletsCount;
    const liveCurrentlyInWarehouse = contractStats
        ? Math.max(0, contractStats.currently_in_warehouse + netChange)
        : 0;
    const liveRemaining = contractStats
        ? Math.max(0, contractStats.total_capacity - liveCurrentlyInWarehouse)
        : 0;

    const breadcrumbs = (
        <div className="flex items-center gap-[6px] text-xs text-text-muted">
            <Home className="h-3.5 w-3.5" />
            <ChevronRight
                className={`h-3.5 w-3.5 ${__("receptions.create_edit.str_8")}`}
            />
            <Link
                href={route("receptions.index")}
                className="hover:text-primary transition-colors"
            >
                {__("receptions.create_edit.reception_vouchers")}
            </Link>
            <ChevronRight
                className={`h-3.5 w-3.5 ${__("receptions.create_edit.str_10")}`}
            />
            <span className="text-primary font-medium">
                {isEdit
                    ? __("receptions.create_edit.edit_voucher")
                    : __("receptions.create_edit.new_voucher")}
            </span>
        </div>
    );

    return (
        <AuthenticatedLayout header={breadcrumbs}>
            <Head
                title={
                    isEdit
                        ? __("receptions.create_edit.edit_reception_voucher")
                        : __("receptions.create_edit.new_reception_voucher")
                }
            />

            <div
                className="max-w-6xl mx-auto pb-12 main-stack-y"
                dir={__("receptions.create_edit.ltr")}
            >
                {/* Page header title bar */}
                <PageHeader
                    icon={Layers}
                    title={
                        isEdit
                            ? __("receptions.create_edit.edit_receipt_reception_serial_")
                            : __("receptions.create_edit.create_new_reception_receipt")
                    }
                    description={
                        <p className="text-xs text-text-muted mt-0.5">
                            {__("receptions.create_edit.fill_out_the_reception_header_")}
                        </p>
                    }
                    actions={
                        <div className="flex items-center gap-2">
                            {/* Save Draft button abbreviated to icon with hover tooltip */}
                            <Tooltip
                                text={
                                    __("receptions.create_edit.save_draft_ctrl_s")
                                }
                            >
                                <button
                                    type="button"
                                    onClick={() =>
                                        handleFormSubmitWithStatus(
                                            "draft",
                                            "edit",
                                        )
                                    }
                                    className="rounded-none h-[30px] w-[30px] p-0 flex items-center justify-center bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 transition-colors"
                                >
                                    <Save className="h-4 w-4" />
                                </button>
                            </Tooltip>

                            {/* Approve & Print button abbreviated to icon with hover tooltip */}
                            <Tooltip
                                text={
                                    __("receptions.create_edit.approve_print_ctrl_e")
                                }
                            >
                                <button
                                    type="button"
                                    onClick={() =>
                                        handleFormSubmitWithStatus(
                                            "approved",
                                            "print",
                                        )
                                    }
                                    className="rounded-none h-[30px] w-[30px] p-0 flex items-center justify-center bg-emerald-600 hover:bg-emerald-700 border border-emerald-700 text-white transition-colors"
                                >
                                    <Printer className="h-4 w-4" />
                                </button>
                            </Tooltip>

                            <div className="h-6 w-px bg-border mx-1" />

                            {/* Back button abbreviated to icon with hover tooltip */}
                            <Tooltip text={__("receptions.create_edit.back")}>
                                <Link
                                    href={
                                        isEdit
                                            ? route(
                                                "receptions.show",
                                                reception.id,
                                            )
                                            : route("receptions.index")
                                    }
                                    className="border border-border bg-surface text-text hover:bg-surface-muted rounded-none h-[30px] w-[30px] flex items-center justify-center transition-all"
                                >
                                    <ArrowRight
                                        className={`h-4 w-4 ${__("receptions.create_edit.rotate_180")}`}
                                    />
                                </Link>
                            </Tooltip>
                        </div>
                    }
                />

                {/* Draft switcher placed below the header title bar */}
                {draftReceptions.length > 0 && (
                    <div className="bg-amber-500/5 border border-amber-500/25 p-3 rounded-none flex flex-wrap items-center gap-3">
                        <span className="text-xs font-bold text-amber-700 flex items-center gap-1">
                            <FolderSync className="h-4 w-4" />
                            {__("receptions.create_edit.active_pending_drafts")}
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                            {draftReceptions.map((draft) => {
                                const draftTooltipText = draft.customer
                                    ? draft.contract
                                        ? `${draft.customer.name} (${draft.contract.contract_number})`
                                        : `${draft.customer.name} - ${__("receptions.create_edit.no_contract_assigned")}`
                                    : __("receptions.create_edit.contract_not_assigned_yet");

                                return (
                                    <Tooltip
                                        key={draft.id}
                                        text={draftTooltipText}
                                    >
                                        <Link
                                            href={route(
                                                "receptions.edit",
                                                draft.id,
                                            )}
                                            className="px-2 py-1 text-[10px] font-bold border border-amber-400 bg-amber-100/50 hover:bg-amber-100 hover:text-amber-800 transition-all rounded-none text-amber-700 inline-block"
                                        >
                                            {draft.serial_number}
                                        </Link>
                                    </Tooltip>
                                );
                            })}
                        </div>
                    </div>
                )}

                <form
                    onSubmit={handleSubmit}
                    className="grid grid-cols-1 lg:grid-cols-4 gap-6"
                >
                    {/* General Inputs Panel */}
                    <div className="lg:col-span-3 space-y-6">
                        {/* Voucher Header Details (collapsible card to optimize vertical layout space) */}
                        <div className="bg-surface border border-border p-5 shadow-sm rounded-none space-y-4">
                            {/* Collapsible header section */}
                            <div className="flex items-center justify-between border-b border-border pb-3">
                                <h3 className="font-bold text-xs text-primary uppercase tracking-wider">
                                    {__("receptions.create_edit.voucher_general_information")}
                                </h3>
                                <button
                                    type="button"
                                    onClick={() =>
                                        setIsGeneralCollapsed(
                                            !isGeneralCollapsed,
                                        )
                                    }
                                    className="text-text-muted hover:text-text focus:outline-none transition-colors"
                                    title={
                                        __("receptions.create_edit.collapse_expand_voucher_info")
                                    }
                                >
                                    {isGeneralCollapsed ? (
                                        <ChevronDown className="h-4 w-4" />
                                    ) : (
                                        <ChevronUp className="h-4 w-4" />
                                    )}
                                </button>
                            </div>

                            {/* Render general info fields conditionally if not collapsed */}
                            {!isGeneralCollapsed && (
                                <>
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        {/* Serial Number */}
                                        <div>
                                            <InputLabel
                                                value={
                                                    __("receptions.create_edit.serial_number")
                                                }
                                            />
                                            <TextInput
                                                type="text"
                                                className="mt-1 w-full text-sm rounded-none border-border bg-slate-50 text-slate-500 font-mono font-bold"
                                                value={
                                                    reception?.serial_number ||
                                                    (__("receptions.create_edit.auto_generated"))
                                                }
                                                disabled
                                                readOnly
                                            />
                                        </div>

                                        {/* 2. Contract SearchableSelect Field (Immediately after Serial Number) */}
                                        <div className="relative">
                                            <SearchableSelect
                                                label={
                                                    __("receptions.create_edit.linked_contract")
                                                }
                                                items={allContracts}
                                                value={data.contract_id}
                                                onChange={(selected) =>
                                                    handleContractSelect(
                                                        selected ? selected.id : "",
                                                    )
                                                }
                                                placeholder={
                                                    __("receptions.create_edit.type_contract_number_or_custom")
                                                }
                                                searchKeys={[
                                                    "contract_number",
                                                    "customer_name",
                                                ]}
                                                displayFormat={(c) =>
                                                    `${c.contract_number} ${c.customer_name
                                                        ? `(${c.customer_name})`
                                                        : ""
                                                    }`
                                                }
                                                valueKey="id"
                                                error={errors.contract_id}
                                                disabled={
                                                    reception?.status ===
                                                    "approved"
                                                }
                                            />
                                        </div>

                                        {/* 3. Customer Autocomplete Field */}
                                        <div className="relative">
                                            <SearchableSelect
                                                label={
                                                    __("receptions.create_edit.customer")
                                                }
                                                items={customers}
                                                value={data.customer_id}
                                                onChange={(selected) => {
                                                    const custId = selected
                                                        ? selected.id
                                                        : "";
                                                    setData("customer_id", custId);
                                                    if (!selected) {
                                                        handleContractSelect("");
                                                    }
                                                }}
                                                placeholder={
                                                    __("receptions.create_edit.type_customer_name")
                                                }
                                                searchKeys={["name"]}
                                                displayFormat={(c) => c.name}
                                                valueKey="id"
                                                error={errors.customer_id}
                                                disabled={
                                                    reception?.status ===
                                                    "approved"
                                                }
                                            />
                                        </div>

                                        {/* Period Select */}
                                        <div>
                                            <InputLabel
                                                value={
                                                    __("receptions.create_edit.linked_period")
                                                }
                                            />
                                            <select
                                                className="mt-1 block w-full border-border bg-surface text-text text-sm focus:border-primary focus:ring-primary rounded-none h-[42px] px-3"
                                                value={data.period_id}
                                                onChange={(e) =>
                                                    setData(
                                                        "period_id",
                                                        e.target.value,
                                                    )
                                                }
                                                disabled={!data.contract_id}
                                                required
                                            >
                                                <option value="">
                                                    {__("receptions.create_edit.select_period")}
                                                </option>
                                                {availablePeriods.map((p) => (
                                                    <option
                                                        key={p.id}
                                                        value={p.id}
                                                    >
                                                        {__("receptions.create_edit.period")}{" "}
                                                        {p.period_number} (
                                                        {p.start_date} إلى{" "}
                                                        {p.end_date})
                                                    </option>
                                                ))}
                                            </select>
                                            <InputError
                                                message={errors.period_id}
                                                className="mt-1"
                                            />
                                        </div>

                                        {/* Driver Select */}
                                        <div>
                                            <div className="flex justify-between items-center">
                                                <InputLabel
                                                    value={
                                                        __("receptions.create_edit.carrier_driver")
                                                    }
                                                />
                                                <button
                                                    type="button"
                                                    onClick={() =>
                                                        setDriverModalOpen(true)
                                                    }
                                                    className="text-[10px] text-primary hover:underline flex items-center gap-0.5"
                                                >
                                                    <UserPlus className="h-3 w-3" />
                                                    {__("receptions.create_edit.new_driver")}
                                                </button>
                                            </div>
                                            <select
                                                className="mt-1 block w-full border-border bg-surface text-text text-sm focus:border-primary focus:ring-primary rounded-none h-[42px] px-3"
                                                value={data.driver_id}
                                                onChange={(e) =>
                                                    setData(
                                                        "driver_id",
                                                        e.target.value,
                                                    )
                                                }
                                            >
                                                <option value="">
                                                    {__("receptions.create_edit.no_driver")}
                                                </option>
                                                {driverList.map((d) => (
                                                    <option
                                                        key={d.id}
                                                        value={d.id}
                                                    >
                                                        {d.name} (
                                                        {d.vehicle_plate} -{" "}
                                                        {d.vehicle_type || "—"})
                                                    </option>
                                                ))}
                                            </select>
                                            <InputError
                                                message={errors.driver_id}
                                                className="mt-1"
                                            />
                                        </div>

                                        {/* Representative Select */}
                                        <div>
                                            <InputLabel
                                                value={
                                                    __("receptions.create_edit.customer_agent")
                                                }
                                            />
                                            <select
                                                className="mt-1 block w-full border-border bg-surface text-text text-sm focus:border-primary focus:ring-primary rounded-none h-[42px] px-3"
                                                value={data.representative_id}
                                                onChange={(e) =>
                                                    setData(
                                                        "representative_id",
                                                        e.target.value,
                                                    )
                                                }
                                                disabled={!data.contract_id}
                                            >
                                                <option value="">
                                                    {__("receptions.create_edit.no_representative")}
                                                </option>
                                                {availableRepresentatives.map(
                                                    (r) => (
                                                        <option
                                                            key={r.id}
                                                            value={r.id}
                                                        >
                                                            {r.name} (
                                                            {r.phone_number})
                                                        </option>
                                                    ),
                                                )}
                                            </select>
                                            <InputError
                                                message={
                                                    errors.representative_id
                                                }
                                                className="mt-1"
                                            />
                                        </div>

                                        {/* Farm / Source Text Input */}
                                        <div>
                                            <InputLabel
                                                value={
                                                    __("receptions.create_edit.farm_source")
                                                }
                                            />
                                            <TextInput
                                                type="text"
                                                className="mt-1 w-full text-sm rounded-none border-border"
                                                placeholder={
                                                    __("receptions.create_edit.e_g_al_qassim_farm")
                                                }
                                                value={data.farm_source}
                                                onChange={(e) =>
                                                    setData(
                                                        "farm_source",
                                                        e.target.value,
                                                    )
                                                }
                                            />
                                            <InputError
                                                message={errors.farm_source}
                                                className="mt-1"
                                            />
                                        </div>

                                        {/* Date Input */}
                                        <div>
                                            <InputLabel
                                                value={
                                                    __("receptions.create_edit.reception_date")
                                                }
                                            />
                                            <TextInput
                                                type="date"
                                                className="mt-1 w-full text-sm rounded-none border-border"
                                                value={data.reception_date}
                                                onChange={(e) =>
                                                    setData(
                                                        "reception_date",
                                                        e.target.value,
                                                    )
                                                }
                                                required
                                            />
                                            <InputError
                                                message={errors.reception_date}
                                                className="mt-1"
                                            />
                                        </div>
                                    </div>

                                    {/* Notes (الملاحظات) */}
                                    <div className="pt-2">
                                        <InputLabel
                                            value={
                                                __("receptions.create_edit.voucher_notes")
                                            }
                                        />
                                        <textarea
                                            className="mt-1 w-full text-sm rounded-none border-border bg-surface text-text focus:border-primary focus:ring-primary min-h-[60px] p-2"
                                            value={data.notes}
                                            onChange={(e) =>
                                                setData("notes", e.target.value)
                                            }
                                            placeholder={
                                                __("receptions.create_edit.write_any_additional_notes_or_")
                                            }
                                        />
                                        <InputError
                                            message={errors.notes}
                                            className="mt-1"
                                        />
                                    </div>

                                    {/* Modification Reason (OPTIONAL in Edit mode) */}
                                    {isEdit && (
                                        <div className="pt-2">
                                            <InputLabel
                                                value={
                                                    __("receptions.create_edit.modification_reason")
                                                }
                                            />
                                            <TextInput
                                                className="mt-1 w-full text-sm rounded-none border-border"
                                                value={data.modification_reason}
                                                onChange={(e) =>
                                                    setData(
                                                        "modification_reason",
                                                        e.target.value,
                                                    )
                                                }
                                                placeholder={
                                                    __("receptions.create_edit.write_why_you_are_editing")
                                                }
                                                required={false}
                                            />
                                            <InputError
                                                message={
                                                    errors.modification_reason
                                                }
                                                className="mt-1"
                                            />
                                        </div>
                                    )}
                                </>
                            )}
                        </div>

                        {/* POS Row Input Bar */}
                        <div className="bg-surface border border-primary/20 p-5 shadow-sm rounded-none space-y-4">
                            <h3 className="font-bold text-xs text-primary border-b border-border pb-2 uppercase tracking-wider flex items-center gap-1.5">
                                <Layers className="h-4 w-4 text-primary" />
                                {__("receptions.create_edit.quick_pos_item_entry")}
                            </h3>

                            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                                {/* Pallet Code/Number input */}
                                <div className="sm:col-span-2">
                                    <InputLabel
                                        value={
                                            __("receptions.create_edit.pallet_no")
                                        }
                                    />
                                    <input
                                        ref={palletInputRef}
                                        type="text"
                                        className="mt-1 block w-full text-xs rounded-none border-border h-[38px] px-2 bg-surface text-text"
                                        placeholder="102"
                                        value={posPalletNumber}
                                        onChange={(e) =>
                                            setPosPalletNumber(e.target.value)
                                        }
                                        onBlur={handlePalletBlur}
                                        onKeyDown={(e) =>
                                            handleKeyNavigation(
                                                e,
                                                sizeSelectRef,
                                                null,
                                            )
                                        }
                                        disabled={loadingPallet}
                                        required
                                    />
                                </div>

                                {/* Size Select */}
                                <div className="sm:col-span-2">
                                    <InputLabel
                                        value={
                                            __("receptions.create_edit.size_type")
                                        }
                                    />
                                    <select
                                        ref={sizeSelectRef}
                                        className="mt-1 block w-full border-border bg-surface text-text text-xs focus:border-primary focus:ring-primary rounded-none h-[38px] px-2"
                                        value={posPalletSize}
                                        onChange={(e) =>
                                            setPosPalletSize(e.target.value)
                                        }
                                        onKeyDown={(e) =>
                                            handleKeyNavigation(
                                                e,
                                                itemSearchRef,
                                                palletInputRef,
                                            )
                                        }
                                        required
                                    >
                                        <option value="صغيرة">
                                            {__("receptions.create_edit.small")}
                                        </option>
                                        <option value="وسط">
                                            {__("receptions.create_edit.medium")}
                                        </option>
                                        <option value="كبيرة">
                                            {__("receptions.create_edit.large")}
                                        </option>
                                        <option value="خشب">
                                            {__("receptions.create_edit.wood")}
                                        </option>
                                        <option value="بلاستيك">
                                            {__("receptions.create_edit.plastic")}
                                        </option>
                                    </select>
                                </div>

                                {/* Item Autocomplete */}
                                <div className="sm:col-span-3 relative">
                                    <SearchableSelect
                                        label={
                                            __("receptions.create_edit.inventory_item")
                                        }
                                        inputRef={itemSearchRef}
                                        items={inventoryItems}
                                        value={posItemId}
                                        onChange={(selected) => {
                                            setPosItemId(
                                                selected ? selected.id : "",
                                            );
                                            if (selected) {
                                                // Using setTimeout to give the blur a chance to finish before jumping focus
                                                setTimeout(() => {
                                                    variantSelectRef.current?.focus();
                                                }, 10);
                                            }
                                        }}
                                        placeholder={
                                            __("receptions.create_edit.search_item")
                                        }
                                        searchKeys={["name", "code"]}
                                        displayFormat={(item) =>
                                            displayBilingual(item.name)
                                        }
                                        valueKey="id"
                                        className="h-[38px] text-xs rounded-none border-border bg-surface text-text"
                                        error=""
                                        renderOption={(item, isActive) => (
                                            <>
                                                <span>
                                                    {displayBilingual(
                                                        item.name,
                                                    )}
                                                </span>
                                                <span
                                                    className={`text-xs ml-2 ${isActive ? "text-white/80" : "text-text-muted"}`}
                                                >
                                                    ({item.code})
                                                </span>
                                            </>
                                        )}
                                    />
                                </div>

                                {/* Variant Select (عبوة) */}
                                <div className="sm:col-span-2">
                                    <InputLabel
                                        value={
                                            __("receptions.create_edit.variant")
                                        }
                                    />
                                    <select
                                        ref={variantSelectRef}
                                        className="mt-1 block w-full border-border bg-surface text-text text-xs focus:border-primary focus:ring-primary rounded-none h-[38px] px-2"
                                        value={posVariantId}
                                        onChange={(e) =>
                                            setPosVariantId(e.target.value)
                                        }
                                        onKeyDown={(e) =>
                                            handleKeyNavigation(
                                                e,
                                                qtyInputRef,
                                                itemSearchRef,
                                            )
                                        }
                                        disabled={!posItemId}
                                        required
                                    >
                                        <option value="">
                                            {__("receptions.create_edit.variant")}
                                        </option>
                                        {posVariants.map((v) => (
                                            <option key={v.id} value={v.id}>
                                                {displayBilingual(v.name)}
                                                {v.quality
                                                    ? ` - ${displayBilingual(v.quality)}`
                                                    : ""}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                                {/* Quality Text Input (درجة) */}
                                <div className="sm:col-span-1">
                                    <InputLabel
                                        value={
                                            __("receptions.create_edit.quality")
                                        }
                                    />
                                    <TextInput
                                        ref={qualityInputRef}
                                        className="mt-1 block w-full text-xs rounded-none border-border h-[38px] bg-slate-50 text-slate-600 font-bold"
                                        value={posQuality}
                                        readOnly
                                    />
                                </div>

                                {/* Quantity Input */}
                                <div className="sm:col-span-1">
                                    <InputLabel
                                        value={
                                            __("receptions.create_edit.qty")
                                        }
                                    />
                                    <input
                                        ref={qtyInputRef}
                                        type="number"
                                        step="1"
                                        min="1"
                                        max="1200"
                                        className="mt-1 block w-16 text-xs rounded-none border-border h-[38px] px-2 bg-surface text-text font-mono"
                                        placeholder="000"
                                        value={posQuantity}
                                        onChange={(e) =>
                                            setPosQuantity(e.target.value)
                                        }
                                        onKeyDown={(e) => {
                                            if (e.key === "Enter") {
                                                e.preventDefault();
                                                handleAddPOSRow();
                                            } else {
                                                handleKeyNavigation(
                                                    e,
                                                    addButtonRef,
                                                    variantSelectRef,
                                                );
                                            }
                                        }}
                                        required
                                    />
                                </div>

                                {/* Add / Update Button */}
                                <div className={editingRowIndex !== null ? "sm:col-span-2 flex gap-1" : "sm:col-span-1"}>
                                    <button
                                        ref={addButtonRef}
                                        type="button"
                                        onClick={handleAddPOSRow}
                                        className={`w-full text-white text-xs font-bold h-[38px] flex items-center justify-center rounded-none transition-all gap-1 ${editingRowIndex !== null
                                            ? "bg-amber-600 hover:bg-amber-700"
                                            : "bg-primary hover:bg-primary/95"
                                            }`}
                                        onKeyDown={(e) =>
                                            handleKeyNavigation(
                                                e,
                                                null,
                                                qtyInputRef,
                                            )
                                        }
                                    >
                                        {editingRowIndex !== null ? (
                                            <>
                                                <Edit className="h-3.5 w-3.5" />
                                                <span>{__("receptions.create_edit.update")}</span>
                                            </>
                                        ) : (
                                            <>
                                                <Plus className="h-3.5 w-3.5" />
                                                <span>{__("receptions.create_edit.insert")}</span>
                                            </>
                                        )}
                                    </button>
                                    {editingRowIndex !== null && (
                                        <button
                                            type="button"
                                            onClick={handleCancelEditRow}
                                            className="px-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold h-[38px] flex items-center justify-center rounded-none transition-all shrink-0"
                                            title={__("receptions.create_edit.cancel_edit")}
                                        >
                                            <X className="h-4 w-4" />
                                        </button>
                                    )}
                                </div>
                            </div>

                            {posRowError && (
                                <div className="bg-danger/10 border border-danger/20 text-danger p-2 text-xs font-bold rounded-none flex items-center gap-1.5">
                                    <AlertCircle className="h-4 w-4" />
                                    <span>{posRowError}</span>
                                </div>
                            )}

                            {/* Helper hint sentence below POS Bar input fields */}
                            <div className="flex flex-wrap items-center justify-between text-[11px] text-text-muted border-t border-border/60 pt-2.5">
                                <div className="flex items-center gap-1.5 font-bold text-primary">
                                    <Search className="h-3.5 w-3.5" />
                                    <span>{__("receptions.create_edit.enter_pallet_number_for_search")}</span>
                                    <span className="text-text-muted font-normal">
                                        {__("receptions.create_edit.on_field_blur_pallet_capacity_")}
                                    </span>
                                </div>
                                {loadingPallet && (
                                    <span className="flex items-center gap-1 text-primary font-bold animate-pulse">
                                        <RefreshCw className="h-3 w-3 animate-spin" />
                                        {__("receptions.create_edit.fetching_pallet_data")}
                                    </span>
                                )}
                            </div>

                            {/* Fetched Pallet Data Card */}
                            {palletLookupData && (
                                <div className="bg-primary/5 border border-primary/20 p-3 rounded-none text-xs space-y-2 font-sans">
                                    <div className="flex flex-wrap justify-between items-center border-b border-primary/10 pb-2 gap-2">
                                        <div className="flex items-center gap-2 font-bold text-text">
                                            <Box className="h-4 w-4 text-primary" />
                                            <span>
                                                {__("receptions.create_edit.pallet_no_palletlookupdata_pal")}
                                            </span>
                                            <span className="font-mono text-[11px] bg-primary/10 text-primary px-1.5 py-0.5 rounded">
                                                {palletLookupData.pallet_code}
                                            </span>
                                            <span className="text-text-muted">
                                                • {__("receptions.create_edit.capacity_size_palletlookupdata")}
                                            </span>
                                        </div>
                                        {palletLookupData.contract && (
                                            <div className="text-[11px] font-bold text-text-muted">
                                                {__("receptions.create_edit.contract")}
                                                <span className="text-primary font-mono">{palletLookupData.contract.contract_number}</span>
                                                {palletLookupData.contract.customer_name && (
                                                    <span> ({palletLookupData.contract.customer_name})</span>
                                                )}
                                            </div>
                                        )}
                                    </div>

                                    {/* Contents & Qualities */}
                                    <div>
                                        <span className="font-bold text-[11px] text-text-muted block mb-1">
                                            {__("receptions.create_edit.current_stored_contents_on_pal")}
                                        </span>
                                        {palletLookupData.contents && palletLookupData.contents.length > 0 ? (
                                            <div className="flex flex-wrap gap-2">
                                                {palletLookupData.contents.map((c, idx) => (
                                                    <div key={idx} className="bg-surface border border-border px-2.5 py-1 text-[11px] font-bold flex items-center gap-1.5 shadow-2xs">
                                                        <span className="text-text">{c.item_name}</span>
                                                        {c.variant_name && <span className="text-text-muted">({c.variant_name})</span>}
                                                        {c.quality && (
                                                            <span className="bg-amber-100 text-amber-800 px-1 py-0.2 text-[10px] rounded">
                                                                {c.quality}
                                                            </span>
                                                        )}
                                                        <span className="text-primary font-mono">{c.quantity} {__("receptions.create_edit.packs")}</span>
                                                    </div>
                                                ))}
                                            </div>
                                        ) : (
                                            <p className="text-[11px] text-text-muted italic">
                                                {__("receptions.create_edit.new_empty_pallet_no_stored_ite")}
                                            </p>
                                        )}
                                    </div>

                                    {/* Warning if occupied on another contract */}
                                    {palletLookupData.is_occupied_elsewhere && palletLookupData.other_contract && (
                                        <div className="bg-amber-500/10 border border-amber-500/30 p-2 text-amber-700 text-[11px] font-bold flex items-center gap-1.5 mt-2">
                                            <AlertCircle className="h-4 w-4 text-amber-600 shrink-0" />
                                            <span>
                                                {__("receptions.create_edit.warning_this_pallet_is_current")}
                                            </span>
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>

                        {/* List of Added Receptions Items */}
                        <div className="bg-surface border border-border p-5 shadow-sm rounded-none space-y-4">
                            <h3 className="font-bold text-xs text-primary border-b border-border pb-2 uppercase tracking-wider">
                                {__("receptions.create_edit.pallets_list_in_this_voucher")}
                            </h3>

                            <div className="overflow-x-auto">
                                <table className="w-full text-xs text-start border border-border">
                                    <thead className="bg-surface-muted text-text-muted font-bold border-b border-border">
                                        <tr>
                                            <th className="px-3 py-2 text-start w-10">
                                                #
                                            </th>
                                            <th className="px-3 py-2 text-start">
                                                {__("receptions.create_edit.pallet_no")}
                                            </th>
                                            <th className="px-3 py-2 text-start">
                                                {__("receptions.create_edit.pallet_size")}
                                            </th>
                                            <th className="px-3 py-2 text-start">
                                                {__("receptions.create_edit.inventory_item")}
                                            </th>
                                            <th className="px-3 py-2 text-start">
                                                {__("receptions.create_edit.variant")}
                                            </th>
                                            <th className="px-3 py-2 text-start">
                                                {__("receptions.create_edit.quality")}
                                            </th>
                                            <th className="px-3 py-2 text-end">
                                                {__("receptions.create_edit.qty_received")}
                                            </th>
                                            <th className="px-3 py-2 text-center w-26">
                                                {__("receptions.create_edit.action")}
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-border">
                                        {data.items.length === 0 ? (
                                            <tr>
                                                <td
                                                    colSpan="8"
                                                    className="px-3 py-6 text-center text-text-muted font-bold"
                                                >
                                                    {__("receptions.create_edit.no_items_added_yet_use_the_pos")}
                                                </td>
                                            </tr>
                                        ) : (
                                            data.items.map((item, index) => {
                                                const inventoryItem =
                                                    inventoryItems.find(
                                                        (i) =>
                                                            i.id ===
                                                            item.inventory_item_id,
                                                    );
                                                const variant =
                                                    inventoryItem?.variants?.find(
                                                        (v) =>
                                                            v.id ===
                                                            item.inventory_item_variant_id,
                                                    );

                                                return (
                                                    <tr
                                                        key={index}
                                                        className={`transition-colors ${editingRowIndex === index
                                                            ? "bg-amber-500/10 border-2 border-amber-400"
                                                            : "hover:bg-slate-50"
                                                            }`}
                                                    >
                                                        <td className="px-3 py-2.5 font-mono text-text-muted">
                                                            {index + 1}
                                                        </td>
                                                        <td className="px-3 py-2.5 font-mono font-bold text-primary">
                                                            {item.pallet_number}
                                                        </td>
                                                        <td className="px-3 py-2.5 font-bold text-text-muted">
                                                            {item.pallet_size}
                                                        </td>
                                                        <td className="px-3 py-2.5 font-bold text-text">
                                                            {displayBilingual(
                                                                inventoryItem?.name,
                                                            )}
                                                        </td>
                                                        <td className="px-3 py-2.5 text-text-muted font-semibold">
                                                            {displayBilingual(
                                                                variant?.name,
                                                            )}
                                                        </td>
                                                        <td className="px-3 py-2.5 text-text-muted">
                                                            {displayBilingual(
                                                                variant?.quality,
                                                            ) || "—"}
                                                        </td>
                                                        <td className="px-3 py-2.5 font-mono font-extrabold text-end text-emerald-600">
                                                            {parseFloat(
                                                                item.quantity_in,
                                                            ).toFixed(2)}
                                                        </td>
                                                        <td className="px-3 py-2.5 text-center space-x-1 rtl:space-x-reverse">
                                                            <button
                                                                type="button"
                                                                onClick={() =>
                                                                    handleEditItemRow(
                                                                        index,
                                                                    )
                                                                }
                                                                className="p-1 text-text-muted hover:text-amber-600 hover:bg-amber-500/10 border border-transparent hover:border-amber-500/25 transition-all rounded-none inline-flex items-center"
                                                                title={
                                                                    __("receptions.create_edit.edit_row")
                                                                }
                                                            >
                                                                <Edit className="h-4 w-4" />
                                                            </button>
                                                            <button
                                                                type="button"
                                                                onClick={() =>
                                                                    handleRemoveItemRow(
                                                                        index,
                                                                    )
                                                                }
                                                                className="p-1 text-text-muted hover:text-danger hover:bg-danger/10 border border-transparent hover:border-danger/25 transition-all rounded-none inline-flex items-center"
                                                                title={
                                                                    __("receptions.create_edit.delete_row")
                                                                }
                                                            >
                                                                <Trash2 className="h-4 w-4" />
                                                            </button>
                                                        </td>
                                                    </tr>
                                                );
                                            })
                                        )}
                                    </tbody>
                                </table>
                            </div>
                            {errors.items && (
                                <p className="text-xs text-danger font-bold mt-1">
                                    {errors.items}
                                </p>
                            )}

                            <div className="flex justify-end gap-3 text-xs text-text-muted mt-2">
                                <div className="font-bold text-text">
                                    {__("receptions.create_edit.total")}
                                </div>
                                <div className="font-mono font-semibold text-text">
                                    {totalReception.toLocaleString(undefined, {
                                        minimumFractionDigits: 0,
                                        maximumFractionDigits: 2,
                                    })}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Sidebar Stats Panel */}
                    <div className="lg:col-span-1 space-y-6">
                        {/* Contract Occupancy Stats Sidebar */}
                        <div className="bg-surface border border-border p-5 shadow-sm rounded-none space-y-4">
                            <div className="flex items-center justify-between border-b border-border pb-3">
                                <div className="flex items-center gap-2">
                                    <Calculator className="h-4 w-4 text-primary" />
                                    <h3 className="font-bold text-xs text-primary uppercase tracking-wider">
                                        {__("receptions.create_edit.contract_capacity_stats")}
                                    </h3>
                                </div>
                                <button
                                    type="button"
                                    onClick={() =>
                                        setIsStatsCollapsed(!isStatsCollapsed)
                                    }
                                    className="text-text-muted hover:text-text focus:outline-none transition-colors"
                                >
                                    {isStatsCollapsed ? (
                                        <ChevronDown className="h-4 w-4" />
                                    ) : (
                                        <ChevronUp className="h-4 w-4" />
                                    )}
                                </button>
                            </div>

                            {!isStatsCollapsed && (
                                <>
                                    {loadingStats ? (
                                        <div className="py-6 text-center text-xs text-text-muted">
                                            {__("receptions.create_edit.loading_stats")}
                                        </div>
                                    ) : contractStats ? (
                                        <div className="space-y-4 text-xs">
                                            <div className="bg-slate-50 border border-border p-3 space-y-3">
                                                <div className="flex justify-between items-center">
                                                    <span className="text-text-muted font-medium">
                                                        {__("receptions.create_edit.total_capacity")}
                                                    </span>
                                                    <span className="font-bold text-text font-mono text-sm">
                                                        {
                                                            contractStats.total_capacity
                                                        }{" "}
                                                        {__("receptions.create_edit.pallets")}
                                                    </span>
                                                </div>
                                                <div className="flex justify-between items-center">
                                                    <span className="text-text-muted font-medium">
                                                        {__("receptions.create_edit.received_in_store")}
                                                    </span>
                                                    <span className="font-bold text-amber-600 font-mono text-sm">
                                                        {
                                                            liveCurrentlyInWarehouse
                                                        }{" "}
                                                        {__("receptions.create_edit.pallets")}
                                                    </span>
                                                </div>
                                                <hr className="border-border" />
                                                <div className="flex justify-between items-center">
                                                    <span className="text-text-muted font-bold">
                                                        {__("receptions.create_edit.remaining_space")}
                                                    </span>
                                                    <span
                                                        className={`font-black font-mono text-[15px] ${liveRemaining > 0 ? "text-emerald-600" : "text-danger"}`}
                                                    >
                                                        {liveRemaining}{" "}
                                                        {__("receptions.create_edit.pallets")}
                                                    </span>
                                                </div>
                                            </div>

                                            {liveRemaining <= 0 && (
                                                <div className="bg-danger/10 border border-danger/25 text-danger font-bold p-3 rounded-none flex items-start gap-1.5 text-[11px]">
                                                    <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                                                    <span>
                                                        {__("receptions.create_edit.contract_has_reached_full_capa")}
                                                    </span>
                                                </div>
                                            )}

                                            {liveRemaining > 0 && (
                                                <div className="bg-emerald-500/10 border border-emerald-500/25 text-emerald-700 font-bold p-3 rounded-none flex items-start gap-1.5 text-[11px]">
                                                    <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
                                                    <span>
                                                        {__("receptions.create_edit.capacity_is_sufficient_for_rec")}
                                                    </span>
                                                </div>
                                            )}

                                            {contractStats.items_breakdown && contractStats.items_breakdown.length > 0 && (
                                                <div className="space-y-2 pt-3 border-t border-border mt-3">
                                                    <h4 className="font-bold text-[11px] text-primary uppercase">
                                                        {__("receptions.create_edit.item_size_breakdown")}
                                                    </h4>
                                                    <div className="space-y-2">
                                                        {contractStats.items_breakdown.map((item, idx) => (
                                                            <div key={idx} className="bg-surface-muted border border-border p-2 text-xs rounded-none space-y-1.5 font-mono shadow-2xs">
                                                                <div className="flex justify-between items-center font-sans font-bold text-text">
                                                                    <span className="truncate max-w-[130px]" title={item.full_name}>📦 {item.label}</span>
                                                                    <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 border border-emerald-300 font-mono text-[10px] font-bold">
                                                                        {__("receptions.create_edit.rem")} {item.available}
                                                                    </span>
                                                                </div>
                                                                <div className="flex justify-between text-[11px] text-text-muted">
                                                                    <span>{__("receptions.create_edit.booked")} <strong className="text-text font-bold">{item.booked}</strong></span>
                                                                    <span className="text-amber-700 font-bold">{__("receptions.create_edit.used")} <strong>{item.utilized}</strong></span>
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    ) : (
                                        <div className="py-4 text-center text-xs text-text-muted">
                                            {__("receptions.create_edit.select_contract_to_calculate_c")}
                                        </div>
                                    )}
                                </>
                            )}
                        </div>
                    </div>
                </form>
            </div>

            {/* Quick Create Driver Modal */}
            <Modal
                show={isDriverModalOpen}
                onClose={() => setDriverModalOpen(false)}
                maxWidth="md"
            >
                <form
                    onSubmit={handleCreateDriver}
                    className="p-6 space-y-4 text-start"
                    dir={__("receptions.create_edit.ltr")}
                >
                    <div className="flex items-center justify-between border-b border-border pb-3">
                        <h3 className="font-bold text-lg text-text">
                            {__("receptions.create_edit.add_new_carrier_driver")}
                        </h3>
                        <button
                            type="button"
                            onClick={() => setDriverModalOpen(false)}
                            className="text-text-muted hover:text-text"
                        >
                            <X className="h-5 w-5" />
                        </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                            <InputLabel
                                value={
                                    __("receptions.create_edit.driver_name")
                                }
                            />
                            <TextInput
                                className="mt-1 w-full text-xs rounded-none border-border"
                                value={newDriverData.name}
                                onChange={(e) =>
                                    setNewDriverData((prev) => ({
                                        ...prev,
                                        name: e.target.value,
                                    }))
                                }
                                required
                            />
                        </div>

                        <div>
                            <InputLabel
                                value={
                                    __("receptions.create_edit.phone_number")
                                }
                            />
                            <TextInput
                                className="mt-1 w-full text-xs rounded-none border-border"
                                value={newDriverData.phone_number}
                                onChange={(e) =>
                                    setNewDriverData((prev) => ({
                                        ...prev,
                                        phone_number: e.target.value,
                                    }))
                                }
                            />
                        </div>

                        <div>
                            <InputLabel
                                value={
                                    __("receptions.create_edit.id_iqama_number")
                                }
                            />
                            <TextInput
                                className="mt-1 w-full text-xs rounded-none border-border"
                                value={newDriverData.id_number}
                                onChange={(e) =>
                                    setNewDriverData((prev) => ({
                                        ...prev,
                                        id_number: e.target.value,
                                    }))
                                }
                            />
                        </div>

                        <div>
                            <InputLabel
                                value={
                                    __("receptions.create_edit.vehicle_plate_no")
                                }
                            />
                            <TextInput
                                className="mt-1 w-full text-xs rounded-none border-border"
                                value={newDriverData.vehicle_plate}
                                onChange={(e) =>
                                    setNewDriverData((prev) => ({
                                        ...prev,
                                        vehicle_plate: e.target.value,
                                    }))
                                }
                            />
                        </div>

                        <div>
                            <InputLabel
                                value={
                                    __("receptions.create_edit.vehicle_type")
                                }
                            />
                            <TextInput
                                className="mt-1 w-full text-xs rounded-none border-border"
                                value={newDriverData.vehicle_type}
                                onChange={(e) =>
                                    setNewDriverData((prev) => ({
                                        ...prev,
                                        vehicle_type: e.target.value,
                                    }))
                                }
                                placeholder={__("receptions.create_edit.dina_trailer_lorry")}
                            />
                        </div>

                        <div>
                            <InputLabel
                                value={
                                    __("receptions.create_edit.driver_license_no")
                                }
                            />
                            <TextInput
                                className="mt-1 w-full text-xs rounded-none border-border"
                                value={newDriverData.license_number}
                                onChange={(e) =>
                                    setNewDriverData((prev) => ({
                                        ...prev,
                                        license_number: e.target.value,
                                    }))
                                }
                            />
                        </div>
                    </div>

                    {driverError && (
                        <p className="text-xs text-danger font-bold">
                            {driverError}
                        </p>
                    )}

                    <div className="flex items-center justify-end gap-2 border-t border-border pt-4">
                        <Tooltip text={__("receptions.create_edit.cancel")}>
                            <button
                                type="button"
                                onClick={() => setDriverModalOpen(false)}
                                className={`border border-border bg-surface text-text hover:bg-surface-muted rounded-none flex items-center justify-center font-bold text-xs transition-all h-[30px] gap-1.5 ${showButtonText ? "px-3" : "w-[30px] p-0"}`}
                            >
                                <X className="h-4 w-4" />
                                {showButtonText && (
                                    <span>
                                        {__("receptions.create_edit.cancel")}
                                    </span>
                                )}
                            </button>
                        </Tooltip>
                        <Tooltip
                            text={__("receptions.create_edit.add_driver")}
                        >
                            <button
                                type="submit"
                                disabled={addingDriver}
                                className={`bg-primary hover:bg-primary/95 text-white rounded-none flex items-center justify-center font-bold text-xs transition-all h-[30px] gap-1.5 ${showButtonText ? "px-3" : "w-[30px] p-0"} disabled:opacity-50`}
                            >
                                <Plus className="h-4 w-4" />
                                {showButtonText && (
                                    <span>
                                        {addingDriver
                                            ? __("receptions.create_edit.adding")
                                            : __("receptions.create_edit.add_driver")}
                                    </span>
                                )}
                            </button>
                        </Tooltip>
                    </div>
                </form>
            </Modal>

            {/* Confirm Secure Delete Modal */}
            <ConfirmationModal
                show={!!deleteItem}
                title={
                    __("receptions.create_edit.confirm_reception_deletion")
                }
                message={
                    __("receptions.create_edit.you_are_about_to_permanently_d")
                }
                onConfirm={() => confirmDelete()}
                onCancel={cancelDelete}
                requirePassword={true}
                passwordValue={deletePassword}
                onPasswordChange={setDeletePassword}
                passwordError={deleteError}
                processing={processingDelete}
            />
        </AuthenticatedLayout>
    );
}
