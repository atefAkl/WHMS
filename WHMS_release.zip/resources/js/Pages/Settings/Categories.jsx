import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { Head, router, useForm } from "@inertiajs/react";
import { useLang } from "@/Contexts/LanguageContext";
import { useState } from "react";
import {
    Layers,
    Plus,
    Edit,
    Trash2,
    Home,
    ChevronRight,
    FolderTree,
    Lock,
} from "lucide-react";
import Pagination from "@/Components/Pagination";
import Modal from "@/Components/Modal";
import ConfirmationModal from "@/Components/ConfirmationModal";
import { useSecureDelete } from "@/Hooks/useSecureDelete";
import TextInput from "@/Components/TextInput";
import InputLabel from "@/Components/InputLabel";
import InputError from "@/Components/InputError";
import PrimaryButton from "@/Components/PrimaryButton";
import SecondaryButton from "@/Components/SecondaryButton";
import DangerButton from "@/Components/DangerButton";
import Tooltip from "@/Components/Tooltip";

export default function Categories({ auth, categories, parentCategories, accounts }) {
    const { lang } = useLang();

    const isSystemCategory = (cat) => {
        const nameEn = String(cat.name_en || "").toLowerCase();
        const nameAr = String(cat.name_ar || "");
        return (
            nameEn === "individual" || 
            nameEn === "individuals" || 
            nameAr === "أفراد" || 
            nameEn === "business" || 
            nameEn === "businesses" || 
            nameAr === "أعمال"
        );
    };

    const [isFormModalOpen, setIsFormModalOpen] = useState(false);
    const [categoryToEdit, setCategoryToEdit] = useState(null);

    const {
        itemToDelete, deletePassword, setDeletePassword, deleteError, processing: deleteProcessing,
        requestDelete, confirmDelete, cancelDelete
    } = useSecureDelete();

    const {
        data,
        setData,
        post,
        put,
        processing,
        errors,
        reset,
        clearErrors,
    } = useForm({
        name_ar: "",
        name_en: "",
        parent_id: "",
        account_id: "",
    });

    const t = {
        title: lang === "ar" ? "تصنيفات العملاء" : "Customer Categories",
        home: lang === "ar" ? "الإعدادات" : "Settings",
        add: lang === "ar" ? "إضافة تصنيف" : "Add Category",
        columns: {
            name: lang === "ar" ? "اسم التصنيف" : "Category Name",
            parent: lang === "ar" ? "التصنيف الرئيسي" : "Main Category",
            actions: lang === "ar" ? "إجراءات" : "Actions",
        },
    };

    const openCreateModal = () => {
        clearErrors();
        reset();
        setCategoryToEdit(null);
        setIsFormModalOpen(true);
    };

    const openEditModal = (category) => {
        clearErrors();
        setData({
            name_ar: category.name_ar,
            name_en: category.name_en,
            parent_id: category.parent_id || "",
            account_id: category.account_id || "",
        });
        setCategoryToEdit(category);
        setIsFormModalOpen(true);
    };

    const closeModals = () => {
        setIsFormModalOpen(false);
        setTimeout(() => {
            reset();
            setCategoryToEdit(null);
            clearErrors();
        }, 200);
    };

    const submitForm = (e) => {
        e.preventDefault();
        if (categoryToEdit) {
            put(route("settings.categories.update", categoryToEdit.id), {
                onSuccess: () => closeModals(),
            });
        } else {
            post(route("settings.categories.store"), {
                onSuccess: () => closeModals(),
            });
        }
    };

    const breadcrumbs = (
        <div className="flex items-center gap-2 text-sm text-text-muted">
            <Home className="h-4 w-4" />
            <ChevronRight
                className={lang === "ar" ? "h-4 w-4 rotate-180" : "h-4 w-4"}
            />
            <span
                className="cursor-pointer hover:text-primary transition-colors"
                onClick={() => router.get(route("settings.index"))}
            >
                {t.home}
            </span>
            <ChevronRight
                className={lang === "ar" ? "h-4 w-4 rotate-180" : "h-4 w-4"}
            />
            <span className="text-primary font-medium">{t.title}</span>
        </div>
    );

    return (
        <AuthenticatedLayout header={breadcrumbs}>
            <Head title={t.title} />

            <div className="py-4">
                <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 main-stack-y">
                    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-6">
                        <div>
                            <h2 className="text-2xl font-bold text-text">
                                {t.title}
                            </h2>
                            <p className="text-sm text-text-muted mt-1">
                                {lang === "ar"
                                    ? "إدارة الهيكل التنظيمي لتصنيفات العملاء"
                                    : "Manage customer categories hierarchy"}
                            </p>
                        </div>
                        <div className="flex items-center gap-3">
                            <button
                                onClick={openCreateModal}
                                className="flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-primary-hover shadow-sm"
                            >
                                <Plus className="h-4 w-4" />
                                {t.add}
                            </button>
                        </div>
                    </div>

                    <div className="rounded-xl border border-border bg-surface shadow-sm overflow-hidden flex flex-col">
                        <div className="border-b border-border p-4 bg-surface-muted/30 flex items-center justify-between">
                            <h3 className="font-semibold text-text flex items-center gap-2">
                                <FolderTree className="h-5 w-5 text-primary" />
                                {lang === "ar"
                                    ? "المخطط العام للتصنيفات"
                                    : "Categories Hierarchy"}
                            </h3>
                            <span className="text-sm text-text-muted font-medium">
                                {categories.total}{" "}
                                {lang === "ar" ? "تصنيف" : "Categories"}
                            </span>
                        </div>

                        <div className="flex-1 bg-surface p-0 min-h-[400px]">
                            {categories.data.length === 0 ? (
                                <div className="flex flex-col items-center justify-center h-full text-text-muted py-20">
                                    <Layers className="h-12 w-12 opacity-20 mb-4" />
                                    <p className="text-lg font-medium">
                                        {lang === "ar"
                                            ? "لم يتم العثور على بيانات"
                                            : "No data found"}
                                    </p>
                                </div>
                            ) : (
                                <div className="overflow-x-auto">
                                    <table className="min-w-full divide-y divide-border">
                                        <thead className="bg-surface-muted/50">
                                            <tr>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-start text-xs font-semibold uppercase tracking-wider text-text-muted"
                                                >
                                                    {t.columns.name}
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-start text-xs font-semibold uppercase tracking-wider text-text-muted"
                                                >
                                                    {t.columns.parent}
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-end text-xs font-semibold uppercase tracking-wider text-text-muted"
                                                >
                                                    {t.columns.actions}
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-border bg-surface">
                                            {categories.data.map((category) => (
                                                <tr
                                                    key={category.id}
                                                    className="transition-colors hover:bg-surface-muted/50"
                                                >
                                                    <td className="whitespace-nowrap px-6 py-4">
                                                        <div className="flex items-center gap-3">
                                                            <div
                                                                className={
                                                                    category.parent_id
                                                                        ? "h-2 w-2 rounded-full bg-emerald-500"
                                                                        : "h-2 w-2 rounded-full bg-primary"
                                                                }
                                                            />
                                                            <div>
                                                                <div className="text-sm font-bold text-text">
                                                                    {lang ===
                                                                    "ar"
                                                                        ? category.name_ar
                                                                        : category.name_en}
                                                                </div>
                                                                <div className="text-xs text-text-muted">
                                                                    {lang ===
                                                                    "ar"
                                                                        ? category.name_en
                                                                        : category.name_ar}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td className="whitespace-nowrap px-6 py-4 text-sm text-text font-medium">
                                                        {category.parent ? (
                                                            <span className="inline-flex items-center rounded-md bg-surface-muted px-2 py-1 text-xs font-medium text-text-muted ring-1 ring-inset ring-border">
                                                                {lang === "ar"
                                                                    ? category
                                                                          .parent
                                                                          .name_ar
                                                                    : category
                                                                          .parent
                                                                          .name_en}
                                                            </span>
                                                        ) : (
                                                            <span className="text-text-muted text-xs italic">
                                                                -
                                                            </span>
                                                        )}
                                                    </td>
                                                    <td className="whitespace-nowrap px-6 py-4 text-end text-sm font-medium">
                                                        {isSystemCategory(category) ? (
                                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200">
                                                                <Lock className="h-3 w-3" />
                                                                {lang === "ar" ? "تصنيف نظام" : "System Category"}
                                                            </span>
                                                        ) : (
                                                            <div className="flex items-center justify-end gap-2">
                                                                <Tooltip
                                                                    text={
                                                                        lang ===
                                                                        "ar"
                                                                            ? "تعديل"
                                                                            : "Edit"
                                                                    }
                                                                >
                                                                    <button
                                                                        onClick={() =>
                                                                            openEditModal(
                                                                                category,
                                                                            )
                                                                        }
                                                                        className="p-1.5 rounded-md text-text-muted hover:text-primary hover:bg-primary/10 transition-colors"
                                                                    >
                                                                        <Edit className="h-4 w-4" />
                                                                    </button>
                                                                </Tooltip>
                                                                <Tooltip
                                                                    text={
                                                                        lang ===
                                                                        "ar"
                                                                            ? "حذف"
                                                                            : "Delete"
                                                                    }
                                                                >
                                                                    <button
                                                                        onClick={() =>
                                                                            requestDelete(route("settings.categories.destroy", category.id), category)
                                                                        }
                                                                        className="p-1.5 rounded-md text-text-muted hover:text-danger hover:bg-danger/10 transition-colors"
                                                                        disabled={deleteProcessing}
                                                                    >
                                                                        <Trash2 className="h-4 w-4" />
                                                                    </button>
                                                                </Tooltip>
                                                            </div>
                                                        )}
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>

                        <Pagination
                            links={categories.links}
                            total={categories.total}
                            from={categories.from}
                            to={categories.to}
                        />
                    </div>
                </div>
            </div>

            {/* Form Modal */}
            <Modal show={isFormModalOpen} onClose={closeModals} maxWidth="md">
                <form onSubmit={submitForm} className="p-6">
                    <h2 className="text-lg font-bold text-text mb-6">
                        {categoryToEdit
                            ? lang === "ar"
                                ? "تعديل التصنيف"
                                : "Edit Category"
                            : t.add}
                    </h2>

                    <div className="space-y-4">
                        <div>
                            <InputLabel
                                htmlFor="name_ar"
                                value={
                                    lang === "ar"
                                        ? "الاسم بالعربية"
                                        : "Arabic Name"
                                }
                            />
                            <TextInput
                                id="name_ar"
                                type="text"
                                className="mt-1 block w-full"
                                value={data.name_ar}
                                onChange={(e) =>
                                    setData("name_ar", e.target.value)
                                }
                                required
                                autoFocus
                            />
                            <InputError
                                message={errors.name_ar}
                                className="mt-1"
                            />
                        </div>
                        <div>
                            <InputLabel
                                htmlFor="name_en"
                                value={
                                    lang === "ar"
                                        ? "الاسم بالإنجليزية"
                                        : "English Name"
                                }
                            />
                            <TextInput
                                id="name_en"
                                type="text"
                                className="mt-1 block w-full text-left"
                                value={data.name_en}
                                onChange={(e) =>
                                    setData("name_en", e.target.value)
                                }
                                required
                                dir="ltr"
                            />
                            <InputError
                                message={errors.name_en}
                                className="mt-1"
                            />
                        </div>
                        <div>
                            <InputLabel
                                htmlFor="parent_id"
                                value={
                                    lang === "ar"
                                        ? "التصنيف الرئيسي (اختياري)"
                                        : "Parent Category (Optional)"
                                }
                            />
                            <select
                                id="parent_id"
                                className="mt-1 block w-full rounded-md border-border bg-surface text-text shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                                value={data.parent_id}
                                onChange={(e) =>
                                    setData("parent_id", e.target.value)
                                }
                            >
                                <option value="">
                                    {lang === "ar"
                                        ? "-- بدون تصنيف رئيسي --"
                                        : "-- No Parent --"}
                                </option>
                                {parentCategories.map((cat) => (
                                    <option key={cat.id} value={cat.id}>
                                        {lang === "ar"
                                            ? cat.name_ar
                                            : cat.name_en}
                                    </option>
                                ))}
                            </select>
                            <InputError
                                message={errors.parent_id}
                                className="mt-1"
                            />
                        </div>
                    </div>

                    <div className="mt-8 flex justify-end gap-3">
                        <SecondaryButton type="button" onClick={closeModals}>
                            {lang === "ar" ? "إلغاء" : "Cancel"}
                        </SecondaryButton>
                        <PrimaryButton disabled={processing}>
                            {lang === "ar" ? "حفظ" : "Save"}
                        </PrimaryButton>
                    </div>
                </form>
            </Modal>

            {/* Delete Modal */}
            <ConfirmationModal
                show={!!itemToDelete}
                title={lang === "ar" ? "تأكيد الحذف" : "Confirm Deletion"}
                message={lang === "ar" ? "هل أنت متأكد من حذف هذا التصنيف؟" : "Are you sure you want to delete this category?"}
                onConfirm={() => confirmDelete()}
                onCancel={cancelDelete}
                requirePassword={true}
                passwordValue={deletePassword}
                onPasswordChange={setDeletePassword}
                passwordError={deleteError}
                processing={deleteProcessing}
            />
        </AuthenticatedLayout>
    );
}
